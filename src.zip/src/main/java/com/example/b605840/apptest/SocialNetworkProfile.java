package com.example.b605840.apptest;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.viewpagerindicator.CirclePageIndicator;

public class SocialNetworkProfile extends AppCompatActivity {

    private Button btnFollow;

    //VIEW PAGER
    private ViewPagerAdapter pageAdapter;
    private ViewPager pager;
    private Activity acti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social_network_profile);

        Typeface typeFace               = Typeface.createFromAsset(getAssets(),"fonts/Raleway-Thin.ttf");
        Typeface typeFace_bold          = Typeface.createFromAsset(getAssets(),"fonts/Raleway-Regular.ttf");

        TextView myTextView             = (TextView)findViewById(R.id.user_name);
        myTextView.setTypeface(typeFace);

        TextView tvUserDesc             = (TextView)findViewById(R.id.user_description);
        tvUserDesc.setTypeface(typeFace);

        btnFollow                       = (Button) findViewById(R.id.follow);
        btnFollow.setTypeface(typeFace);

        TextView tvAmountFollowers      = (TextView)findViewById(R.id.amount_followers);
        tvAmountFollowers.setTypeface(typeFace_bold);

        TextView tvFollowers            = (TextView)findViewById(R.id.followers);
        tvFollowers.setTypeface(typeFace);

        TextView tvAmountFollowing      = (TextView)findViewById(R.id.amount_following);
        tvAmountFollowing.setTypeface(typeFace_bold);

        TextView tvFollowing            = (TextView)findViewById(R.id.following);
        tvFollowing.setTypeface(typeFace);

        //INIT VIEWPAGER
        initViewPager();

        btnFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (btnFollow.getText().equals("Follow")){
                    btnFollow.setBackground(getResources().getDrawable(R.drawable.button_bg_transparent_active));
                    btnFollow.setText("Following");
                    btnFollow.setTextColor(getResources().getColor(R.color.bck_active_green));
                } else {
                    btnFollow.setBackground(getResources().getDrawable(R.drawable.button_bg_transparent));
                    btnFollow.setText("Follow");
                    btnFollow.setTextColor(getResources().getColor(R.color.bck_generic));
                }
            }
        });
    }

    public void initViewPager(){
        acti = this;
        pager = (ViewPager) findViewById(R.id.pager);
        pageAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        pageAdapter.addFragment(GeneralInformationFragment.newInstance(acti));
        pageAdapter.addFragment(OptionsPortfolioFragment.newInstance(acti));
        this.pager.setAdapter(pageAdapter);

        CirclePageIndicator indicator = (CirclePageIndicator) findViewById(R.id.indicatorPager);
        indicator.setPageColor(Color.parseColor("#2B2F3E"));
        indicator.setViewPager(pager);
    }
}
