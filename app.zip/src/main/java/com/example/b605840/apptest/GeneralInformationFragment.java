package com.example.b605840.apptest;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.Utils;

import java.util.ArrayList;

public class GeneralInformationFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private Context context;
    private TextView tvCurrentDate;
    private TextView tvVariation;
    private LineChart mChart;

    private TextView mDateDay;
    private TextView mDateWeek;
    private TextView mDateMonth;
    private TextView mDateYear;

    public void setContext(Context c)
    {
        context = c;
    }


    public GeneralInformationFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static GeneralInformationFragment newInstance(Context context) {

        GeneralInformationFragment fragment = new GeneralInformationFragment();
        fragment.setContext(context);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ViewGroup rootView      = (ViewGroup) inflater.inflate(R.layout.fragment_general_information, container, false);

        Typeface typeFace       = Typeface.createFromAsset(context.getAssets(),"fonts/Raleway-Thin.ttf");
        Typeface typeFace_bold  = Typeface.createFromAsset(context.getAssets(),"fonts/Raleway-Regular.ttf");

        tvCurrentDate           = (TextView)rootView.findViewById(R.id.current_date);
        tvCurrentDate.setTypeface(typeFace);

        tvVariation             = (TextView)rootView.findViewById(R.id.variation);
        tvVariation.setTypeface(typeFace_bold);

        mDateDay                = (TextView)rootView.findViewById(R.id.date_day);
        mDateDay.setTypeface(typeFace_bold);

        mDateWeek               = (TextView)rootView.findViewById(R.id.date_week);
        mDateWeek.setTypeface(typeFace_bold);

        mDateMonth              = (TextView)rootView.findViewById(R.id.date_month);
        mDateMonth.setTypeface(typeFace_bold);

        mDateYear               = (TextView)rootView.findViewById(R.id.date_year);
        mDateYear.setTypeface(typeFace_bold);

        mChart = (LineChart) rootView.findViewById(R.id.chart);

        //Init Chart
        initChart();

        mDateDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDateDay.setTextColor(getResources().getColor(R.color.main_background_dark));
                mDateDay.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);
                mDateWeek.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateWeek.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateMonth.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateMonth.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateYear.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateYear.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
            }
        });

        mDateWeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDateWeek.setTextColor(getResources().getColor(R.color.main_background_dark));
                mDateWeek.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);
                mDateDay.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateDay.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateMonth.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateMonth.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateYear.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateYear.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
            }
        });

        mDateMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDateMonth.setTextColor(getResources().getColor(R.color.main_background_dark));
                mDateMonth.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);
                mDateDay.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateDay.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateWeek.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateWeek.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateYear.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateYear.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
            }
        });

        mDateYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDateYear.setTextColor(getResources().getColor(R.color.main_background_dark));
                mDateYear.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);
                mDateDay.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateDay.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateWeek.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateWeek.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
                mDateMonth.setTextColor(getResources().getColor(R.color.gray_intense_medium));
                mDateMonth.setTextSize(TypedValue.COMPLEX_UNIT_SP,15);
            }
        });

        return rootView;
    }

    public void initChart(){

        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(24000f, 0));
        entries.add(new Entry(28000f, 1));
        entries.add(new Entry(26000f, 2));
        entries.add(new Entry(22000f, 3));
        entries.add(new Entry(35000f, 4));
        entries.add(new Entry(31000f, 5));
        entries.add(new Entry(33000f, 6));
        entries.add(new Entry(34000f, 7));

        LineDataSet dataset = new LineDataSet(entries, "");
        ArrayList<String> labels = new ArrayList<String>();

        for (int j = 0; j < entries.size(); j++) {
            labels.add("");
        }

        LineData data = new LineData(labels, dataset);
        dataset.setDrawValues(false);


        //For gradient fill
        if (Utils.getSDKInt() >= 18) {
            // fill drawable only supported on api level 18 and above
            Drawable drawable = null;

            drawable = ContextCompat.getDrawable(context, R.drawable.fade_green);      //DEGRADADO
            dataset.setColors(new int[]{ColorTemplate.rgb("#08C184")});             //LINEA SUPERIOR AL DEGRADADO

            drawable.setAlpha(200);
            dataset.setFillDrawable(drawable);
            dataset.setDrawFilled(true);

        } else {

            dataset.setColors(new int[]{ColorTemplate.rgb("#08C184")});             //LINEA SUPERIOR, AQUI NO HABRA DEGRADADO

        }

        dataset.setLineWidth(2f);
        dataset.setDrawCircles(false);
        mChart.setData(data);

        //Set Custom offset
        mChart.setViewPortOffsets(0,0,0,0);

        //For remove legends and numbers in rigth and left side
        mChart.setDescription("");
        mChart.getLegend().setEnabled(false);

        //FOR REMOVE GRID
        //AXIS Y
        YAxis leftAxis = mChart.getAxisLeft();
        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setDrawAxisLine(false);
        leftAxis.setDrawAxisLine(false);
        leftAxis.setDrawGridLines(false);
        rightAxis.setDrawGridLines(false);
        leftAxis.setEnabled(false);
        rightAxis.setEnabled(false);
        mChart.setDrawBorders(false);

        //REMOVE GRID AXIS X
        mChart.getXAxis().setDrawGridLines(false);
        mChart.getXAxis().setDrawAxisLine(false);
        mChart.getXAxis().setEnabled(false);

        //ZOOM
        mChart.setPinchZoom(true);

        //ANIMATE THE CHART
        mChart.animateY(2000);
    }
}
