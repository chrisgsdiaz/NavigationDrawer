package com.example.b605840.apptest;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OptionsPortfolioFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private Context context;
    private TextView tvComparate;
    private TextView tvSector;
    private TextView tvAlzasBajas;
    private TextView tvInbox;

    private LinearLayout mSectionAlzasBajas;

    public void setContext(Context c)
    {
        context = c;
    }

    public OptionsPortfolioFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static OptionsPortfolioFragment newInstance(Context context) {
        OptionsPortfolioFragment fragment = new OptionsPortfolioFragment();
        fragment.setContext(context);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ViewGroup rootView       = (ViewGroup) inflater.inflate(R.layout.fragment_options_portfolio, container, false);

        Typeface typeFace               = Typeface.createFromAsset(context.getAssets(),"fonts/Raleway-Thin.ttf");
        Typeface typeFace_bold          = Typeface.createFromAsset(context.getAssets(),"fonts/Raleway-Regular.ttf");

        tvComparate                     = (TextView)rootView.findViewById(R.id.comparate);
        tvComparate.setTypeface(typeFace_bold);

        tvSector                    = (TextView)rootView.findViewById(R.id.tvSector);
        tvSector.setTypeface(typeFace_bold);

        tvAlzasBajas                    = (TextView)rootView.findViewById(R.id.tvAlzasBajas);
        tvAlzasBajas.setTypeface(typeFace_bold);
        mSectionAlzasBajas              = (LinearLayout)rootView.findViewById(R.id.section_alzas_bajas);

        tvInbox                         = (TextView)rootView.findViewById(R.id.message_inbox);
        tvInbox.setTypeface(typeFace_bold);

        mSectionAlzasBajas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intentAlzasBajas = new Intent(getActivity(), AlzasBajasActivity.class);
                startActivity(intentAlzasBajas);

            }
        });

        return rootView;
    }
}
